//
//  _Core_DataApp.swift
//   Core Data
//
//  Created by Christine N. on 08/02/2024.
//

import SwiftUI

@main
struct _Core_DataApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
