//
//  Dessert+CoreDataProperties.swift
//   Core Data
//
//  Created by Christine N. on 08/02/2024.
//
//

import Foundation
import CoreData


extension Dessert {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Dessert> {
        return NSFetchRequest<Dessert>(entityName: "Dessert")
    }


}

extension Dessert : Identifiable {

}
