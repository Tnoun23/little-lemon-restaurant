//
//  Dish+CoreDataClass.swift
//   Core Data
//
//  Created by Christine N. on 08/02/2024.
//
//

import Foundation
import CoreData

@objc(Dish)
public class Dish: NSManagedObject {
    
    // 4. Create Core Data classes -> in _Core_Data, 2 new entities were created: Location & Dessert, with Codegen = Manual/None. Then...

    //let newDish = NSEntityDescription.insertNewObject(forEntityName: "Dish", into: viewContext) OR
    let newDish = Dish(context: viewContext)
    newDish.name = "Apple Pie"
    newDish.size = "Ex. Large"
    newDish.price = 10
}
