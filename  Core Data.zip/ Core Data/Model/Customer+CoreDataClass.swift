//
//  Customer+CoreDataClass.swift
//   Core Data
//
//  Created by Christine N. on 08/02/2024.
//
//

import Foundation
import CoreData

@objc(Customer)
public class Customer: NSManagedObject {

}
