//
//  Location+CoreDataClass.swift
//   Core Data
//
//  Created by Christine N. on 09/02/2024.
//
//

import Foundation
import CoreData

@objc(Location)
public class Location: NSManagedObject {

}
