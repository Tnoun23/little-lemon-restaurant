//
//  Location+CoreDataProperties.swift
//   Core Data
//
//  Created by Christine N. on 09/02/2024.
//
//

import Foundation
import CoreData


extension Location {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Location> {
        return NSFetchRequest<Location>(entityName: "Location")
    }

    @NSManaged public var name: String?

}

extension Location : Identifiable {

}
